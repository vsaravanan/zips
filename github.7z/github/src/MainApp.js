import React from 'react'
import { Provider } from 'react-redux'
import { ConnectedRouter } from 'connected-react-router'
import { Route, Switch } from 'react-router'
import configureStore, { history } from './store'
import AppWithRouterAccess from './router/AppWithRouterAccess'
import 'assets/styles/bootstrap.css'
import MainPage from 'components/paxtrax/mainpage'

import CreateRole from 'components/CreateRole/CreateRole'
import MaintainRole from 'components/MaintainRole/MaintainRole'
import MaintainReferenceData from 'components/MaintainReferenceData/MaintainReferenceData'
const store = configureStore()

class MainApp extends React.Component {
  render() {
    return (
      <div className='App'>
        <Provider store={store}>
          <ConnectedRouter history={history}>
            {/* <Switch> */}
            <AppWithRouterAccess />

            {/* <Route path='/create-role' component={CreateRole} />
            <Route path='/maintain-role' component={MaintainRole} />
            <Route path='/maintain-ref' component={MaintainReferenceData} /> */}
            {/* <Route path='/' component={MainPage} />
            </Switch> */}
          </ConnectedRouter>
        </Provider>
      </div>
    )
  }
}

export default MainApp
