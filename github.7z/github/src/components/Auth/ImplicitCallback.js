import React from "react";
import { LoginCallback } from "@okta/okta-react";
import Dashboard from "../Screens/Dashboard";
const ImplicitCallback = () => <LoginCallback errorComponent={Dashboard} />;

export default ImplicitCallback;
