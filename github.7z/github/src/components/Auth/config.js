const oktaAuthConfig = {
  // Note: If your app is configured to use the Implicit Flow
  // instead of the Authorization Code with Proof of Code Key Exchange (PKCE)
  // you will need to add `pkce: false`
  //   pkce: false,
  issuer: "https://dev-99199095.okta.com/oauth2/default",
  clientId: "0oa5la03q92tZ1uei5d6",
  redirectUri: "http://localhost:3000/implicit/callback",
};

const oktaSignInConfig = {
  baseUrl: "https://dev-99199095.okta.com",
  clientId: "0oa5la03q92tZ1uei5d6",
  redirectUri: "http://localhost:3000/implicit/callback",
  logo:'dfs-logo.png',
  authParams: {
    // If your app is configured to use the Implicit Flow
    // instead of the Authorization Code with Proof of Code Key Exchange (PKCE)
    // you will need to uncomment the below line
    // pkce: false
  },
};

export { oktaAuthConfig, oktaSignInConfig };
