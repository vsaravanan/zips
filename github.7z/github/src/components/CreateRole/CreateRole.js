import React, { useState } from 'react'
import { connect } from 'react-redux'

import { Multiselect } from 'components/UI/Input/MultiSelect/multiselect.component'

import * as labels from 'constants/Labels'

import TextInput from 'components/UI/Input/TextInput'
import { newRoleName, newRoleScreen, setNewRole, saveRole } from 'actions/action-roles'

const MaintainRole = props => {
  const { setRoleName, setRoleScreen, setRole, createdRole, screens } = props

  const handleCancel = () => {
    setRole({
      id: null,
      name: '',
      screenDetails: [],
    })
  }

  const onSelect = (selectedList, selectedItem) => {
    setRoleScreen(selectedList)
  }

  const onRemove = (selectedList, selectedItem) => {
    setRoleScreen(selectedList)
  }

  return (
    <div className='container bg-white'>
      <h1 className='mb-5 mt-5 display-6'>{labels.TITLE_1}</h1>

      <div className='mb-3'>
        <TextInput
          name={labels.NAME_LABEL_1}
          value={createdRole.name}
          typed={event => setRoleName(event.target.value)}
        />
      </div>

      <div className='mb-4'>
        <label className='form-label h6'>{labels.DETAILS_LABEL_1}</label>

        <Multiselect
          displayValue='name'
          options={screens}
          selectedValues={createdRole.screenDetails}
          showCheckbox={true}
          closeOnSelect={false}
          onSelect={onSelect}
          onRemove={onRemove}
        />
      </div>
      <div className='row'>
        <div className='col text-right'>
          <button type='button' onClick={saveRole('SAVED')} className='btn btn-primary mr-3'>
            {labels.SAVE_BUTTON}
          </button>

          <button type='button' onClick={handleCancel} className=' btn btn-outline-secondary'>
            {labels.CANCEL_BUTTON}
          </button>
        </div>
      </div>
    </div>
  )
}

const mapStateToProps = state => ({
  createdRole: state.rolesReducer.newRole,
  roles: state.rolesReducer.roles,
  screens: state.rolesReducer.screens,
})

const mapDispatchToProps = dispatch => ({
  setRoleName: name => dispatch(newRoleName(name)),
  setRoleScreen: screen => dispatch(newRoleScreen(screen)),
  setRole: role => dispatch(setNewRole(role)),
  saveRole: msg => dispatch(saveRole(msg)),
})

export default connect(mapStateToProps, mapDispatchToProps)(MaintainRole)
