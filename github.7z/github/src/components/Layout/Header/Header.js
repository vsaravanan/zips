import React from 'react'
import { Row, Col, Container } from "react-bootstrap"
import BreadCrumb from "../BreadCrumb/BreadCrumb";
import Logo from '../../../assets/images/dfs-logo.png'
import {BiUserCircle} from "react-icons/bi"
import { IoLanguageOutline } from "react-icons/io5";
import { AiOutlineClockCircle } from "react-icons/ai";

function Header({path}) {
    return (
      <div style={{ width: "100%" }}>
        <Container fluid style={{ paddingLeft: 0, paddingRight: 0 }}>
          <Row style={{ width: "100%", paddingLeft: 0, paddingRight: 0 }}>
            <Col xs={6} md={6} style={{ paddingRight: 0, paddingLeft: "10px" }}>
              <img src={Logo} className='logo' alt="DFS Logo"/>
            </Col>
            <Col
              xs={6}
              md={6}
              style={{
                paddingLeft: 0,
                paddingRight: 0,
              }}
            >
              <Row
                style={{
                  paddingLeft: 0,
                  paddingRight: 0,
                  margin: 0,
                  height: "100%",
                }}
              >
                <Col xs={5} md={5} className='header-text border-right'>
                  <AiOutlineClockCircle /> &nbsp;
                  <span className='header-title'>7:42(Paris / Venice time)</span>
                </Col>
                <Col xs={3} md={3} className='header-text border-right'>
                  <IoLanguageOutline />{" "}
                  <span className='header-title'>English</span>
                </Col>
                <Col xs={4} md={4} className='header-text border-right'>
                  <BiUserCircle /> &nbsp;
                  <span className='header-title'>Test User</span>
                </Col>
              </Row>
            </Col>
          </Row>
          <Row style={{ width: "100%", paddingLeft: 0, paddingRight: 0 }}>
            <Col style={{ paddingLeft: 0, paddingRight: 0 }}>
              <BreadCrumb path={path} />
            </Col>
          </Row>
        </Container>
      </div>
    );
}

export default Header
