import React,{ useState,useEffect } from 'react'
import SideBar from "./Sidebar/SideBar";
import Header from "./Header/Header";


export default function Layout(props) {
  const [path, setpath] = useState('');

  useEffect(() => {
    if (path !== window.location.pathname) setpath(`${window.location.pathname}`)
  })
 
    return (
      <div className='content'>
        <div className='one'>
          <SideBar currentPath={path}/>
        </div>
        <div className='two'>
          <Header path={path} />
          <div style={{ padding: '0.5rem', width: '100%', boxSizing: 'border-box' }}>
            { props.children}
          </div>
        </div>
      </div>
    )
}
