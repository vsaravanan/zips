import React,{useState,useEffect} from 'react'
import './SideBarStyle.css'
import { AdministarationSidebarData,BagTrackingSidebarData,CustomsSidebarData } from "./SideBarData";
import { AiOutlineHome } from "react-icons/ai";
import { IoBagOutline, IoFolderOutline } from "react-icons/io5";
import {  FiCommand } from "react-icons/fi";
import SubMenu from './SubMenu';

function SideBar({ currentPath }) {
  
  const [path, setPath] = useState('')
  
   
  useEffect(() => {
    if (path !== currentPath) setPath(currentPath)
  })

  return (
    <div className='wrapper'>
      <div className='sidebar'>
        <ul className='sidebarList'>
          <li className='row'>
            <div id='icon1'>
              <AiOutlineHome style={{ marginBottom: '3px' }} />
            </div>
            <div id='title1'>HOME</div>
          </li>

          <hr
            style={{
              width: '85%',
              color: 'whitesmoke',
              borderTop: '1px solid #cccccc',
            }}
          />
          <li className='row'>
            <div id='icon1'>
              <FiCommand style={{ marginBottom: '3px' }} />
            </div>
            <div id='title1'>ADMINISTARATION</div>
          </li>

          {AdministarationSidebarData.map((val, key) => (
            <SubMenu item={val} index={key} currentPath={path} />
          ))}

          <hr
            style={{
              textAlign: 'start',
              width: '80%',
              borderTop: '1px solid #cccccc',
            }}
          />

          <li className='row'>
            <div id='icon1'>
              <IoFolderOutline style={{ marginBottom: '3px' }} />
            </div>

            <div id='title1'>CUSTOMS</div>
          </li>
          {CustomsSidebarData.map((val, key) => (
            <SubMenu item={val} index={key} currentPath={path} />
          ))}
          <hr
            style={{
              width: '80%',
              color: 'white',
              borderTop: '1px solid #cccccc',
            }}
          />
          <li className='row'>
            <div id='icon1'>
              <IoBagOutline style={{ marginBottom: '3px' }} />
            </div>
            <div id='title1'>BAG TRACKING</div>
          </li>
          {BagTrackingSidebarData.map((val, key) => (
            <SubMenu item={val} index={key} currentPath={path} />
          ))}
        </ul>
      </div>
    </div>
  )
}

export default SideBar
