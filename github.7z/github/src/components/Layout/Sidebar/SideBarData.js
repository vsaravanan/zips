import React from "react";
import * as AiIcons from "react-icons/ai";
import * as RiIcons from "react-icons/ri";

export const AdministarationSidebarData = [
  {
    title: "Security",
    icon: <AiIcons.AiOutlineHome />,
    link: "/administartion/security",
    iconOpened: <RiIcons.RiArrowDownSFill />,
    iconClosed: <RiIcons.RiArrowRightSFill />,
    subNav: [
      {
        title: "Maintain User",
        path: "/administartion/security/maintain-user",
      },
      {
        title: "Create Role",
        path: "/administartion/security/create-role",
      },
      {
        title: "Maintain Role",
        path: "/administartion/security/maintain-role",
      },
      {
        title: "Maintain Refrence Data",
        path: "/administartion/security/maintain-ref",
      },
    ],
  },
  {
    title: "Carrier",
    icon: <AiIcons.AiOutlineHome />,
    link: "null",
    iconOpened: <RiIcons.RiArrowDownSFill />,
    iconClosed: <RiIcons.RiArrowRightSFill />,
    subNav:[
      {
        title: "Maintain User",
        path: "/administartion/Carrier/maintainUser",
      },
      {
        title: "Create Role",
        path: "/administartion/Carrier/createRole",
      },
      {
        title: "Maintain Role",
        path: "/administartion/Carrier/maintainRole",
      },
      {
        title: "Maintain Refrence Data",
        path: "/administartion/Carrier/maintain-ref",
      },
    ],
  },
  {
    title: "Location",
    icon: <AiIcons.AiOutlineHome />,
    link: "null",
    iconOpened: <RiIcons.RiArrowDownSFill />,
    iconClosed: <RiIcons.RiArrowRightSFill />,
    subNav: [
      {
        title: "Maintain User",
        path: "/administartion/Carrier/maintainUser",
      },
      {
        title: "Create Role",
        path: "/administartion/Carrier/createRole",
      },
      {
        title: "Maintain Role",
        path: "/administartion/Carrier/maintainRole",
      },
      {
        title: "Maintain Refrence Data",
        path: "/administartion/Carrier/maintain-ref",
      },
    ],
  },
  {
    title: "Rac Pre-assignment",
    icon: <AiIcons.AiOutlineHome />,
    link: "null",
    iconOpened: <RiIcons.RiArrowDownSFill />,
    iconClosed: <RiIcons.RiArrowRightSFill />,
    subNav: [
      {
        title: "Maintain User",
        path: "/administartion/Carrier/maintainUser",
      },
      {
        title: "Create Role",
        path: "/administartion/Carrier/createRole",
      },
      {
        title: "Maintain Role",
        path: "/administartion/Carrier/maintainRole",
      },
      {
        title: "Maintain Refrence Data",
        path: "/administartion/Carrier/maintain-ref",
      },
    ],
  },
];


export const CustomsSidebarData = [
  {
    title: "Administaration",
    icon: <AiIcons.AiOutlineHome />,
    link: "null",
    iconOpened: <RiIcons.RiArrowDownSFill />,
    iconClosed: <RiIcons.RiArrowRightSFill />,
    subNav: [
      {
        title: "Maintain User",
        path: "/customs/administartion/maintainUser",
      },
      {
        title: "Create Role",
        path: "/customs/administartion/createRole",
      },
      {
        title: "Maintain Role",
        path: "/customs/administartion/maintainRole",
      },
      {
        title: "Maintain Refrence Data",
        path: "/customs/administartion/maintainRef",
      },

    ],
  },
  {
    title: "NACCS Processing",
    icon: <AiIcons.AiOutlineHome />,
    link: "null",
    iconOpened: <RiIcons.RiArrowDownSFill />,
    iconClosed: <RiIcons.RiArrowRightSFill />,
    subNav: [
      {
        title: "Maintain User",
        path: "/administartion/Carrier/maintainUser",
      },
      {
        title: "Create Role",
        path: "/administartion/Carrier/createRole",
      },
      {
        title: "Maintain Role",
        path: "/administartion/Carrier/maintainRole",
      },
    ],
  },
  {
    title: "Enquiries/Reports",
    icon: <AiIcons.AiOutlineHome />,
    link: "null",
    iconOpened: <RiIcons.RiArrowDownSFill />,
    iconClosed: <RiIcons.RiArrowRightSFill />,
    subNav: [
      {
        title: "Maintain User",
        path: "/administartion/Carrier/maintainUser",
      },
      {
        title: "Create Role",
        path: "/administartion/Carrier/createRole",
      },
      {
        title: "Maintain Role",
        path: "/administartion/Carrier/maintainRole",
      },
    ],
  },
  {
    title: "Merge Pax",
    iconOpened: <RiIcons.RiArrowDownSFill />,
    iconClosed: <RiIcons.RiArrowRightSFill />,
    subNav: [
      {
        title: "Maintain User",
        path: "/administartion/Carrier/maintainUser",
      },
      {
        title: "Create Role",
        path: "/administartion/Carrier/createRole",
      },
      {
        title: "Maintain Role",
        path: "/administartion/Carrier/maintainRole",
      },
    ],
  },
];
export const BagTrackingSidebarData = [
  {
    title: "Administaration",
    icon: <AiIcons.AiOutlineHome />,
    link: "null",
    iconOpened: <RiIcons.RiArrowDownSFill />,
    iconClosed: <RiIcons.RiArrowRightSFill />,
    subNav: [
      {
        title: "Maintain User",
        path: "/customs/administartion/maintainUser",
      },
      {
        title: "Create Role",
        path: "/customs/administartion/createRole",
      },
      {
        title: "Maintain Role",
        path: "/customs/administartion/maintainRole",
      },
    ],
  },
  {
    title: "Enquiries/Reports",
    icon: <AiIcons.AiOutlineHome />,
    link: "null",
    iconOpened: <RiIcons.RiArrowDownSFill />,
    iconClosed: <RiIcons.RiArrowRightSFill />,
    subNav: [
      {
        title: "Maintain User",
        path: "/administartion/Carrier/maintainUser",
      },
      {
        title: "Create Role",
        path: "/administartion/Carrier/createRole",
      },
      {
        title: "Maintain Role",
        path: "/administartion/Carrier/maintainRole",
      },
    ],
  },
];