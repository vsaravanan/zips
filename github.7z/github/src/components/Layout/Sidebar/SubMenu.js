import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import styled from 'styled-components'

const StyledLink = styled(Link)`
  text-decoration: none;

  &:focus,
  &:hover,
  &:visited,
  &:link,
  &:active {
    text-decoration: none;
  }

  &:active {
    color: white;
  }
`

export default function SubMenu({ item, index, clicked, currentPath }) {
  const [subNav, setSubNav] = useState(false)
  const [path, setPath] = useState('')

  const showSubmenu = () => {
    setSubNav(!subNav)
  }

  useEffect(() => {
    if (path !== currentPath) setPath(currentPath)
  })


  return (
    <>
      <li
        key={index}
        className='row'
        onClick={item.subNav && showSubmenu}
        style={{ cursor: 'pointer' }}
      >
        <div id='title'>{item.title}</div>
        <div id='icon'>
          {item.subNav && subNav ? item.iconOpened : item.subNav ? item.iconClosed : null}
        </div>
      </li>
      <div>
        {subNav &&
          item.subNav.map((val, key) => {
            return (
              <StyledLink to={val.path} style={{ textDecoration: 'none' }} key={key}>
                <li className='row'>
                  <div id='title'>
                    <div
                      className={`${val.path === path ? 'active' : 'inactive'}`}
                      style={{
                        width: '84%',
                      }}
                    >
                      <span style={{ paddingLeft: '12px' }}>{val.title}</span>
                    </div>
                  </div>
                </li>
              </StyledLink>
            )
          })}
      </div>
    </>
  )
}
