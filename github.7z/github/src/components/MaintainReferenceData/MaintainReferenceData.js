import React, { useState } from 'react'
import { connect } from 'react-redux'
import {Input,Row,Col} from 'react-bootstrap'
import { AgGridColumn, AgGridReact } from 'ag-grid-react';
import '../../css/maintainreferencedata.css'
import 'ag-grid-enterprise';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import { useFormik } from "formik";


const rowStyle = {
  fontSize: '0.82rem',
  // 'border-right-color': '#e2e2e2',
  'border-right-color': '#e2e2e2',
  height: '50px',
  display: 'flex',
  justifyContent: 'flex-start',
  alignItems: 'center'
}

const actionCellRenderer = (params) => {
  
  let divElement = document.createElement('div')

  let editingCells = params.api.getEditingCells()

  // checks if the rowIndex matches in at least one of the editing cells
  let isCurrentRowEditing = editingCells.some(cell => {
    return cell.rowIndex === params.node.rowIndex
  })

  if (isCurrentRowEditing) {
    divElement.innerHTML = `
<button data-action="save"  class="save-option"> Save  </button>
<button  data-action="cancel" class="cancel-option"> Cancel </button>
`
  } else {
    divElement.innerHTML = `
<button data-action="edit" class="edit-option"> Edit </button>
`
  }

  return divElement
}

let initialValues={};
function MaintainReferenceData (props) {
    const [gridApi, setGridApi] = useState(null);
    const [gridColumnApi, setGridColumnApi] = useState(null);
    const [refValue, setRefValue] = useState(null);
    const [rowData, setRowData] = useState([
        { code: "123", value: "22", NCSS: 35000,store: "abc",international:true },
        { code: "212", value: "11", NCSS: 32000 ,store: "xyz" ,international:true},
        { code: "121", value: "33", NCSS: 72000 , store: "qaz",international:true}
    ]);
 

    
    const [refDropdown, setRefDropDown] = useState([
      "Air line","Airport", "Curencies", "DP Tracking", "Nationality", "Purchase Type" , "Promotion","Location Type","Pickup Location","Shift"
    ]);

   const columnDefs = [
      {
        headerName: 'Code',
        field: 'code',
        lockPosition: true,
        sortable: true,
        filter: true,
        cellStyle: rowStyle,
        flex: 1,
        editable: true,
      },
      {
        headerName: 'Value',
        field: 'value',
        lockPosition: true,
         sortable: true,
        filter: true,
        cellStyle: rowStyle,
        editable: true,
        flex: 1,
      },
      {
        headerName: 'NCSS',
        field: 'NCSS',
        sortable: true,
        filter: true,
        lockPosition: true,
         cellStyle: rowStyle,
        flex: 1,
        editable: true,
        border: true,
      },
   
      {
        headerName: 'Action',
        field: 'action',
        cellRenderer: actionCellRenderer,
        editable: false,
        colId: 'action',
        cellStyle: rowStyle,
        flex: 1,
      },
    ]; 

    const columnDefs1 = [
      {
        headerName: 'Code',
        field: 'code',
        sortable: true,
        lockPosition: true,
        filter: true,
        cellStyle: rowStyle,
        flex: 1,
        editable: true,
      },
      {
        headerName: 'Value',
        field: 'value',
        lockPosition: true,
        sortable: true,
        filter: true,
        cellStyle: rowStyle,
        editable: true,
        flex: 1,
      },
      {
        headerName: 'Store',
        field: 'store',
        sortable: true,
       
        lockPosition: true,
         filter: true,
        cellStyle: rowStyle,
        flex: 1,
        editable: true,
        border: true,
      },
   
      {
        headerName: 'Action',
        field: 'action',
        cellRenderer: actionCellRenderer,
        editable: false,
        colId: 'action',
        cellStyle: rowStyle,
        flex: 1,
      },
    ]; 
    const columnDefs2 = [
      {
        headerName: 'Code',
        field: 'code',
        sortable: true,
        lockPosition: true,
         filter: true,
        cellStyle: rowStyle,
        flex: 1,
        editable: true,
      },
      {
        headerName: 'Value',
        field: 'value',
        lockPosition: true,
         sortable: true,
        filter: true,
        cellStyle: rowStyle,
        editable: true,
        flex: 1,
      },
      {
        headerName: 'International',
        field: 'international',
        sortable: true,
        filter: true,
        cellStyle: rowStyle,
        lockPosition: true,
        flex: 1,
        editable: true,
        border: true,
      },
   
      {
        headerName: 'Action',
        field: 'action',
        cellRenderer: actionCellRenderer,
        editable: false,
        colId: 'action',
        cellStyle: rowStyle,
        flex: 1,
      },
    ]; 


    const columnDefs3 = [
      {
        headerName: 'Code',
        field: 'code',
        sortable: true,
        filter: true,
        cellStyle: rowStyle,
        flex: 1,
        editable: true,
        lockPosition: true
      },
      {
        headerName: 'Value',
        field: 'value',
        sortable: true,
        filter: true,
        cellStyle: rowStyle,
        editable: true,
        flex: 1,lockPosition: true
      },
      {
        headerName: 'From Hours',
        field: 'from',
        sortable: true,
        filter: true,
        cellStyle: rowStyle,
        lockPosition: true,
        flex: 1,
        editable: true,
        border: true,
      },
      {
        headerName: 'To Hours',
        field: 'from',
        sortable: true,
        filter: true,
        cellStyle: rowStyle,
        lockPosition: true,
        flex: 1,
        editable: true,
        border: true,
      },
   
      {
        headerName: 'Action',
        field: 'action',
        cellRenderer: actionCellRenderer,
        editable: false,
        colId: 'action',
        cellStyle: rowStyle,
        flex: 1,
      },
    ]; 
    const columnDefs4= [
      {
        headerName: 'Code',
        field: 'code',
        sortable: true,
        filter: true,
        cellStyle: rowStyle,
        flex: 1,
        editable: true,
        lockPosition: true
      },
      {
        headerName: 'Value',
        field: 'value',
        sortable: true,
        filter: true,
        cellStyle: rowStyle,
        editable: true,
        flex: 1,lockPosition: true
      },
    
   
      {
        headerName: 'Action',
        field: 'action',
        cellRenderer: actionCellRenderer,
        editable: false,
        colId: 'action',
        cellStyle: rowStyle,
        flex: 1,
      },
    ]; 

    const defaultColDef= {
      flex: 1,
      resizable: true,
      filter: true,
      // floatingFilter: true,
      // editable: true,
      borders: true,
      field: 'value',
      cellEditorSelector: function (params) {
        console.log('ind', params)
        if (params.colDef.field === 'international') {
          return {
            component: 'agSelectCellEditor',
            params: {
              values: ['true', 'false'],
            },
          }
        }
        return null
      },
    };

   const onCellClicked=(params) => {
      // Handle click event for action cells
      if (params.column.colId === 'action' && params.event.target.dataset.action) {
        let action = params.event.target.dataset.action
  
        if (action === 'edit') {
          params.api.startEditingCell({
            rowIndex: params.node.rowIndex,
            // gets the first columnKey
            colKey: params.columnApi.getDisplayedCenterColumns()[0].colId,
          })
        }
  
        if (action === 'save') {
          params.api.stopEditing(false)
        }
  
        if (action === 'cancel') {
          params.api.stopEditing(true)
        }
      }
    }
  
   const onRowEditingStarted = (params) => {
      params.api.refreshCells({
        columns: ['action'],
        rowNodes: [params.node],
        force: true,
      })
    }
  const  onRowEditingStopped = (params) => {
      params.api.refreshCells({
        columns: ['action'],
        rowNodes: [params.node],
        force: true,
      })
    }

    const formik = useFormik({
        enableReinitialize: true,
        initialValues,
      });

      useState(() => {
        initialValues.Reference = "";
      
      });

    function onGridReady(params) {
        setGridApi(params.api);
        setGridColumnApi(params.columnApi);
    }
    return(
        <div className="maintain-ref-data">
            <div className="title">Maintain Reference Data</div>
<div className="top">
<div  className="head1">Select reference data type to maintain. </div>

<div className="head2">Reference type</div>
<div>
<select className="ref-options" value={formik.values.Reference}  onChange={formik.handleChange}
                  name="Reference">
<option value="">Select</option>
   { refDropdown.map((val)  => {;return( <option value={val}>{val}</option>);})
}
   </select></div>
  
</div>
<div className="head3">Reference Data</div>
{formik.values.Reference === "Air line" ?
  <div className="ag-theme-alpine data-column" >
       <AgGridReact
            columnDefs={columnDefs}
            rowData={rowData}
            animateRows={true}
            rowHeight={50}
            headerHeight={55}  
            pagination={true}
            paginationAutoPageSize={true}
            context={props.context}
            onGridReady={onGridReady}
            onRowEditingStopped={onRowEditingStopped}
            onRowEditingStarted={onRowEditingStarted}
            onCellClicked={onCellClicked}
            editType='fullRow'
            suppressClickEdit={true}
          />
 
</div>:(formik.values.Reference === "Location Type")?
 <div className="ag-theme-alpine data-column" >
 <AgGridReact
            columnDefs={columnDefs1}
            rowData={rowData}
            animateRows={true}
            rowHeight={50}
            headerHeight={55}  
            pagination={true}
            paginationAutoPageSize={true}
            context={props.context}
            onGridReady={onGridReady}
            onRowEditingStopped={onRowEditingStopped}
            onRowEditingStarted={onRowEditingStarted}
            onCellClicked={onCellClicked}
            editType='fullRow'
            suppressClickEdit={true}
          />

</div>
:(formik.values.Reference === "Pickup Location")?
<div className="ag-theme-alpine data-column" >
<AgGridReact
           columnDefs={columnDefs2}
           rowData={rowData}
           animateRows={true}
           rowHeight={50}
           headerHeight={55}  
           defaultColDef={defaultColDef}
           pagination={true}
           paginationAutoPageSize={true}
           context={props.context}
           onGridReady={onGridReady}
           onRowEditingStopped={onRowEditingStopped}
           onRowEditingStarted={onRowEditingStarted}
           onCellClicked={onCellClicked}
           editType='fullRow'
           suppressClickEdit={true}
         />

</div>:(formik.values.Reference === "Shift")?
<div className="ag-theme-alpine data-column" >
<AgGridReact
           columnDefs={columnDefs3}
           rowData={rowData}
           animateRows={true}
           rowHeight={50}
           headerHeight={55}  
           defaultColDef={defaultColDef}
           pagination={true}
           paginationAutoPageSize={true}
           context={props.context}
           onGridReady={onGridReady}
           onRowEditingStopped={onRowEditingStopped}
           onRowEditingStarted={onRowEditingStarted}
           onCellClicked={onCellClicked}
           editType='fullRow'
           suppressClickEdit={true}
         />

</div>:(formik.values.Reference === "")?null:<div className="ag-theme-alpine data-column" >
<AgGridReact
           columnDefs={columnDefs4}
           rowData={rowData}
           animateRows={true}
           rowHeight={50}
           headerHeight={55}  
           defaultColDef={defaultColDef}
           pagination={true}
           paginationAutoPageSize={true}
           context={props.context}
           onGridReady={onGridReady}
           onRowEditingStopped={onRowEditingStopped}
           onRowEditingStarted={onRowEditingStarted}
           onCellClicked={onCellClicked}
           editType='fullRow'
           suppressClickEdit={true}
         /></div>}</div>
    );
}
export default MaintainReferenceData;

