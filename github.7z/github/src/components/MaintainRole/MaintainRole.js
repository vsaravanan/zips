import React, { useState } from 'react'
import { connect } from 'react-redux'

import { Multiselect } from 'components/UI/Input/MultiSelect/multiselect.component'

import * as labels from 'constants/Labels'

import DropdownInput from 'components/UI/Input/DropdownInput'
import TextInput from 'components/UI/Input/TextInput'
import { editRoleName, editRoleScreen, setMaintainedRole, saveRole } from 'actions/action-roles'

const MaintainRole = props => {
  const { setRoleName, setRoleScreen, setRole, selectedRole, roles, screens } = props

  const [currentRoleName, setCurrentRoleName] = useState(selectedRole.name)

  const handleRoleChosen = event => {
    setRole(
      Object.assign(
        ...roles.filter(role => {
          return role.name === event.target.value
        }),
      ),
    )

    setCurrentRoleName(event.target.value)
  }

  const handleCancel = () => {
    setRole(
      Object.assign(
        ...roles.filter(role => {
          return role.name === currentRoleName
        }),
      ),
    )
  }

  const onSelect = (selectedList, selectedItem) => {
    setRoleScreen(selectedList)
  }

  const onRemove = (selectedList, selectedItem) => {
    setRoleScreen(selectedList)
  }

  return (
    <div className='container bg-white'>
      <h1 className='mb-5 mt-5 display-6'>{labels.TITLE_2}</h1>

      <div className='mb-3'>
        <DropdownInput
          name={labels.NAME_LABEL_1}
          value={selectedRole}
          changed={handleRoleChosen}
          options={roles}
        />
      </div>

      <div className='mb-3'>
        <TextInput
          name={labels.NAME_LABEL_1}
          value={selectedRole.name}
          typed={event => setRoleName(event.target.value)}
        />
      </div>

      <div className='mb-4'>
        <label className='form-label h6'>{labels.DETAILS_LABEL_1}</label>

        <Multiselect
          displayValue='name'
          options={screens}
          selectedValues={selectedRole.screenDetails}
          showCheckbox={true}
          closeOnSelect={false}
          onSelect={onSelect}
          onRemove={onRemove}
        />
      </div>
      <div className='row'>
        <div className='col text-right'>
          <button type='button' onClick={saveRole('SAVED')} className='btn btn-primary mr-3'>
            {labels.SAVE_BUTTON}
          </button>

          <button type='button' onClick={handleCancel} className=' btn btn-outline-secondary'>
            {labels.CANCEL_BUTTON}
          </button>
        </div>
      </div>
    </div>
  )
}

const mapStateToProps = state => ({
  selectedRole: state.rolesReducer.maintainedRole,
  roles: state.rolesReducer.roles,
  screens: state.rolesReducer.screens,
})

const mapDispatchToProps = dispatch => ({
  setRoleName: name => dispatch(editRoleName(name)),
  setRoleScreen: screen => dispatch(editRoleScreen(screen)),
  setRole: role => dispatch(setMaintainedRole(role)),
  saveRole: msg => dispatch(saveRole(msg)),
})

export default connect(mapStateToProps, mapDispatchToProps)(MaintainRole)
