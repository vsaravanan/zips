import React, { Component } from 'react'
import { AgGridReact } from 'ag-grid-react'
import 'ag-grid-community/dist/styles/ag-theme-alpine.css'
import 'ag-grid-community/dist/styles/ag-grid.css'
import { Container, Row, Col } from 'react-bootstrap'
import "./MaintainUser.css";
import { AiOutlineDelete } from 'react-icons/ai';

const icons = {
  sortAscending: '<i class="fa fa-sort-alpha-down"/>',
  sortDescending: '<i class="fa fa-sort-alpha-down"/>'
}

const rowStyle = {
  border:'none',
  display: 'flex',
  justifyContent: 'flex-start',
  alignItems: 'center',
  fontWeight:400,
'font-size': '14px',
'line-height': '150%',
color: '#161616'
}

const actionCellRenderer = (params) => {
  
  let divElement = document.createElement('div')

  let editingCells = params.api.getEditingCells()

  // checks if the rowIndex matches in at least one of the editing cells
  let isCurrentRowEditing = editingCells.some(cell => {
    return cell.rowIndex === params.node.rowIndex
  })

  if (isCurrentRowEditing) {
    divElement.innerHTML = `
<button data-action="save"  class="save-option"> Save  </button>
<button  data-action="cancel" class="cancel-option"> Cancel </button>
`
  } else {
    divElement.innerHTML = `
<button data-action="edit" class="edit-option"> Edit </button>  
<a data-action="delete" class="fa fa-trash" style="font-size:16px;color:#666666"></a>
`
  }

  return divElement
}

export default class MaintainUser extends Component {
  constructor(props) {
    super(props)

    this.state = {
      rowData: null,
      columnDefs: [
        {
          headerName: 'User ID',
          field: 'userId',
          sortable: true,
          filter: true,
          cellStyle: rowStyle,
          flex: 1,
        },
        {
          headerName: 'Employee ID',
          field: 'employeeId',
          sortable: true,
          filter: true,
          cellStyle: rowStyle,
          flex: 1,
        },
        {
          headerName: 'First Name',
          field: 'firstName',
          sortable: true,
          filter: true,
          cellStyle: rowStyle,
          flex: 1,
          editable: true,
          border: true,
        },
        {
          headerName: 'Last Name',
          field: 'lastName',
          sortable: true,
          filter: true,
          cellStyle: rowStyle,
          flex: 1,
          editable: true,
        },
        {
          headerName: 'Role',
          field: 'role',
          sortable: true,
          filter: true,
          cellStyle: rowStyle,
          flex: 1,
          editable: true,
        },
        {
          
          field: 'action',
          cellRenderer: actionCellRenderer,
          editable: false,
          colId: 'action',
          cellStyle: rowStyle,
          flex: 1,
        },
      ],
      rowData: [
        {
          userId: 121,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 11,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 21,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 41,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 121,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 121,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 11,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 21,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 41,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 121,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 121,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 11,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 21,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 41,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 121,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 121,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 11,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 21,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 41,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 121,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 121,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 11,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 21,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 41,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 121,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 121,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 11,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 21,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 41,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 121,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 121,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 11,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 21,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 41,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
        {
          userId: 121,
          employeeId: 'dsasd',
          firstName: 'first',
          lastName: 'last',
          role: 'asdddd',
        },
      ],
      defaultColDef: {
        flex: 1,
        resizable: true,
        filter: true,
        wrapText: true,
        autoHeight: true,
        // floatingFilter: true,
        // editable: true,
        field: 'value',
        cellClassRules: 'no-border-cell',
        cellEditorSelector: function (params) {
          if (params.colDef.field === 'role') {
            return {
              component: 'agSelectCellEditor',
              params: {
                values: ['a', 'b'],
              },
            }
          }
          return null
        },
      },
      rowClassRules: {
        'odd-rows': function (params) {
          return params.rowIndex%2 === 0
         
        },
      },
    }
  }

  

  // This function will be called when grid is ready and loaded
  onGridReady = params => {
    this.gridApi = params.api
    this.gridColumnApi = params.columnApi
  }

  onCellClicked(params) {
    // Handle click event for action cells
    if (params.column.colId === 'action' && params.event.target.dataset.action) {
      let action = params.event.target.dataset.action

      if (action === 'edit') {
        params.api.startEditingCell({
          rowIndex: params.node.rowIndex,
          // gets the first columnKey
          colKey: params.columnApi.getDisplayedCenterColumns()[0].colId,
        })
      }

      if (action === 'delete') {
        console.log('asdas')
        params.api.applyTransaction({
          remove: [params.node.data],
        })
      }

      if (action === 'save') {
        params.api.stopEditing(false)
      }

      if (action === 'cancel') {
        params.api.stopEditing(true)
      }
    }
  }

  onRowEditingStarted(params) {
    params.api.refreshCells({
      columns: ['action'],
      rowNodes: [params.node],
      force: true,
    })
  }
  onRowEditingStopped(params) {
    params.api.refreshCells({
      columns: ['action'],
      rowNodes: [params.node],
      force: true,
    })
  }

  render() {
    return (
      <Container style={{ margin: 'auto', width: '90%' }}>
        <Row>
          <Col>
            <h3 style={{ marginBottom: 35, marginTop: 35 }}>Maintain User</h3>
          </Col>
        </Row>
        <Row>
          <Col>
            <div
              id='myGrid'
              className='ag-theme-alpine'
              style={{
                width: '100%',
                height: 800,
              }}
            >
              <AgGridReact
                columnDefs={this.state.columnDefs}
                rowData={this.state.rowData}
                animateRows={true}
                // rowHeight={50}
                // headerHeight={48}
                rowClassRules={this.state.rowClassRules}
                defaultColDef={this.state.defaultColDef}
                pagination={true}
                paginationAutoPageSize={true}
                context={this.state.context}
                onGridReady={this.onGridReady}
                onRowEditingStopped={this.onRowEditingStopped}
                onRowEditingStarted={this.onRowEditingStarted}
                onCellClicked={this.onCellClicked}
                editType='fullRow'
                suppressClickEdit={true}
              />
            </div>
          </Col>
        </Row>
      </Container>
    )
  }
}
