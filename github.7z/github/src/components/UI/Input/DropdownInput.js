import React from 'react'

const DropdownInput = props => {
  return (
    <div className='mb-3'>
      <label className='form-label h6'>{props.name}</label>
      <select className='form-control' onChange={props.changed}>
        {props.options.map(opt => (
          <option value={opt.name} key={opt.id}>
            {opt.name}
          </option>
        ))}
      </select>
    </div>
  )
}

export default DropdownInput
