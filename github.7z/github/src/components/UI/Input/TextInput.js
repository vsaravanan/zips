import React from 'react'

const TextInput = props => {
  return (
    <div class='mb-3'>
      <label class='form-label h6'>{props.name}</label>
      <input
        type='text'
        name={props.name}
        onChange={props.typed}
        value={props.value}
        class='form-control'
      />
    </div>
  )
}

export default TextInput
