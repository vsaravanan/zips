import React, { Component, Fragment } from 'react'
import './paxtrax.css'

export default class MainPage extends Component {
  render() {
    var tmp = "MainPage"
    return (
      <Fragment>
        <div className='someclass'>{tmp}</div>
      
      </Fragment>
    )
  }
}
