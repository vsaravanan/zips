export const TITLE_1 = 'Create Role'
export const TITLE_2 = 'Maintain Role'

export const NAME_LABEL_1 = 'Role Name'
export const DETAILS_LABEL_1 = 'Applicable Screens'

export const SAVE_BUTTON = 'Save'
export const CANCEL_BUTTON = 'Cancel'
export const GO_BUTTON = 'Go'
