export const roles = [
  {
    id: 1,
    name: 'Role-01',
    screenDetails: [
      { id: 'a1', name: '01' },
      { id: 'a2', name: '02' },
      { id: 'a3', name: '03' },
    ],
  },
  {
    id: 2,
    name: 'Role-02',
    screenDetails: [
      { id: 'b1', name: '04' },
      { id: 'b2', name: '05' },
      { id: 'b3', name: '06' },
    ],
  },
  {
    id: 3,
    name: 'Role-03',
    screenDetails: [
      { id: 'c1', name: '07' },
      { id: 'c2', name: '08' },
      { id: 'c3', name: '09' },
    ],
  },
]
