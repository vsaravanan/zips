export const screens = [
  { id: 'a1', name: '01' },
  { id: 'a2', name: '02' },
  { id: 'a3', name: '03' },
  { id: 'b1', name: '04' },
  { id: 'b2', name: '05' },
  { id: 'b3', name: '06' },
  { id: 'c1', name: '07' },
  { id: 'c2', name: '08' },
  { id: 'c3', name: '09' },
  { id: 'd1', name: '10' },
  { id: 'd2', name: '11' },
  { id: 'd3', name: '12' },
]
