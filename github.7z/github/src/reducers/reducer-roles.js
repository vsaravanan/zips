import {
  SET_MAINTAINED_ROLE,
  EDIT_ROLE_NAME,
  EDIT_ROLE_SCREEN,
  SAVE_ROLE,
  SET_NEW_ROLE,
  SET_NEW_ROLE_NAME,
  SET_NEW_ROLE_SCREEN,
} from 'actions/action-roles'

//use fetch or axios to retrieve roles and screens from db
import { roles } from 'constants/Roles'
import { screens } from 'constants/Screens'

const initialState = {
  maintainedRole: {
    id: roles[0].id,
    name: roles[0].name,
    screenDetails: roles[0].screenDetails,
  },

  newRole: {
    id: null,
    name: '',
    screenDetails: [],
  },

  roles: roles,
  screens: screens,
}

export default (state = initialState, action) => {
  switch (action.type) {
    case EDIT_ROLE_NAME:
      return {
        ...state,
        maintainedRole: {
          ...state.maintainedRole,
          name: action.payload,
        },
      }

    case EDIT_ROLE_SCREEN:
      return {
        ...state,
        maintainedRole: {
          ...state.maintainedRole,
          screenDetails: action.payload,
        },
      }

    case SET_MAINTAINED_ROLE:
      return {
        ...state,
        maintainedRole: action.payload,
      }

    case SET_NEW_ROLE_NAME:
      return {
        ...state,
        newRole: {
          ...state.newRole,
          name: action.payload,
        },
      }

    case SET_NEW_ROLE_SCREEN:
      return {
        ...state,
        newRole: {
          ...state.newRole,
          screenDetails: action.payload,
        },
      }

    case SET_NEW_ROLE:
      return {
        ...state,
        newRole: action.payload,
      }

    case SAVE_ROLE:
      console.log('POST REQUEST HERE')
      console.log(action.payload)
      break

    default:
      return state
  }
}
