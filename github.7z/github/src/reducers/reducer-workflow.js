import { roles } from 'constants/Roles'

const initialState = {
  roles: [...roles],
}

export default (state = initialState, action) => {
  switch (action.type) {
    case 'workflow': {
      return {
        ...state,
        current: action.workflow,
      }
    }

    default:
      return state
  }
}
