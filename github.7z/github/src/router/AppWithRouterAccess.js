import React from "react";
import { Route, useHistory, Switch } from "react-router-dom";
import { Security, SecureRoute, LoginCallback } from "@okta/okta-react";
import { OktaAuth } from "@okta/okta-auth-js";
import MaintainRole from "../components/MaintainRole/MaintainRole";
import MaintainReferenceData from "../components/MaintainReferenceData/MaintainReferenceData";
import CreateRole from "../components/CreateRole/CreateRole";
import Login from "../components/Auth/Login";
import { oktaAuthConfig, oktaSignInConfig } from "../components/Auth/config";
import Layout from "components/Layout/Layout";
import MaintainUser from "components/MaintainUser/MaintainUser";

const oktaAuth = new OktaAuth(oktaAuthConfig);

const AppWithRouterAccess = () => {
  const history = useHistory();

  const customAuthHandler = () => {
    history.push("/login");
  };

  return (
    <Security oktaAuth={oktaAuth} onAuthRequired={customAuthHandler}>
      <Switch>
        <SecureRoute
          path='/administartion/security/maintain-role'
          exact={true}
          render={() => (
            <Layout>
              <MaintainRole />
            </Layout>
          )}
        />

        <SecureRoute
          path='/administartion/security/create-role'
          exact={true}
          render={() => (
            <Layout>
              <CreateRole />
            </Layout>
          )}
        />
          <SecureRoute
          path='/administartion/security/maintain-ref'
          exact={true}
          render={() => (
            <Layout>
              <MaintainReferenceData />
            </Layout>
          )}
        />

        <SecureRoute
          path='/administartion/security/maintain-user'
          exact={true}
          render={() => (
            <Layout>
              <MaintainUser />
            </Layout>
          )}
        />
         <SecureRoute
          path='/administartion/Carrier/maintainRef'
          exact={true}
          render={() => (
            <Layout>
              <MaintainReferenceData />
            </Layout>
          )}
        />

        {/* <SecureRoute path='/protected' component={Protected} /> */}
        <Route path='/login' render={() => <Login config={oktaSignInConfig} />} />
        <Route path='/login/callback' component={LoginCallback} />
        <SecureRoute
          path='*'
          render={() => (
            <Layout>
              <div style={{ width: '100%', textAlign: 'center', marginTop: '10%' }}>
                This page does not exist
              </div>
            </Layout>
          )}
        />
      </Switch>
    </Security>
  )
};
export default AppWithRouterAccess;
